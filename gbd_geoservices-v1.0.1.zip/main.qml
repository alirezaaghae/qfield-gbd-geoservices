import QtQuick
import QtQuick.Controls
import QtCore
import org.qfield
import org.qgis
import Theme

import "js/geoservices.js" as GS

Item {
    id: plugin
    objectName: "gbdGeoServicesPlugin"

    readonly property var mainWindow: iface.mainWindow()
    readonly property var mapCanvas: iface.mapCanvas()
    readonly property var pointHandler: iface.findItemByObjectName("pointHandler")
    readonly property var projectInfo: iface.findItemByObjectName("projectInfo")
    readonly property var geometryHighlighter: iface.findItemByObjectName("geometryHighlighter")
    readonly property var wgs84: QfCoordinateReferenceSystemUtils.wgs84Crs()

    property var metadata: null
    property var generations: ({})
    property int requestSequence: 0
    property var lastSearchOptions: null
    property var resultObjects: []
    property var resultLayer: null
    property var basemapLayer: null
    property bool pointSearchActive: false

    Settings {
        id: settings
        // Keep the original category so existing installations retain their
        // service URL and API key when switching to this clean-room rewrite.
        category: "gbd_geoservices"
        property string baseUrl: "https://geoservices.gbd-consult.de"
        property string apiKey: ""
        property string authcfg: ""
    }

    function t(source, values) { return GS.tr(source, values); }
    function member(object, name) {
        var value = object[name];
        return typeof value === "function" ? value.call(object) : value;
    }

    function toast(message) {
        mainWindow.displayToast(message);
        iface.logMessage("GBD GeoServices: " + message);
    }

    function configure() {
        panel.openAt(2);
    }

    function openPanel() {
        pointSearchActive = false;
        panel.openAt(0);
        if (metadata === null) { refreshCatalog(); }
    }

    function layerIsValid(layer) {
        if (!layer) { return false; }
        if (typeof layer.isValid === "function") { return Boolean(layer.isValid()); }
        if (layer.valid !== undefined) { return Boolean(layer.valid); }
        return true;
    }

    function request(operation, method, path, payload, success, failure) {
        var base;
        try {
            base = GS.validateBaseUrl(settings.baseUrl);
        } catch (error) {
            failure(error.message);
            return;
        }
        var xhr = new XMLHttpRequest();
        xhr.open(method, base + path);
        xhr.timeout = 30000;
        xhr.setRequestHeader("Accept", "application/json");
        if (settings.apiKey) { xhr.setRequestHeader("Authorization", "Bearer " + settings.apiKey.trim()); }
        if (payload !== null) { xhr.setRequestHeader("Content-Type", "application/json"); }
        xhr.onreadystatechange = function () {
            if (xhr.readyState !== XMLHttpRequest.DONE) { return; }
            if (xhr.status === 401 || xhr.status === 403) {
                failure(t("Authentication failed. Check the API key."));
                return;
            }
            if (xhr.status < 200 || xhr.status >= 300) {
                failure(t("Request failed ({status}). Check the service URL and connection.", { status: xhr.status || "offline" }));
                return;
            }
            try {
                success(JSON.parse(xhr.responseText));
            } catch (error) {
                failure(t("The service returned an unexpected response: {error}", { error: error.message }));
            }
        };
        xhr.onerror = function () { failure(t("Network request failed. Check connectivity and the service URL.")); };
        xhr.ontimeout = function () { failure(t("The request timed out. Try again.")); };
        xhr.send(payload === null ? null : JSON.stringify(payload));
    }

    function refreshCatalog() {
        panel.setCatalogLoading();
        request("metadata", "GET", "/metadata", null, function (json) {
            metadata = GS.parseMetadata(json);
            panel.setMetadata(metadata);
        }, function (message) { panel.setCatalogError(message); });
        request("status", "GET", "/status", null, function (json) {
            var status = GS.parseStatus(json);
            generations = status.generations;
            panel.setServiceStatus(status.raw, Object.keys(generations).length);
        }, function (message) { panel.setServiceError(message); });
    }

    function saveSettings(baseUrl, apiKey, authcfg) {
        try {
            settings.baseUrl = GS.validateBaseUrl(baseUrl);
        } catch (error) {
            panel.setSettingsError(error.message);
            return;
        }
        settings.apiKey = apiKey.trim();
        settings.authcfg = authcfg.trim();
        metadata = null;
        panel.setSettingsSaved();
    }

    function canvasBoundsWgs84() {
        var extent = mapCanvas.mapSettings.extent;
        var rectangle = QfGeometryUtils.reprojectRectangle(extent, mapCanvas.mapSettings.destinationCrs, wgs84);
        return [member(rectangle, "xMinimum"), member(rectangle, "yMinimum"), member(rectangle, "xMaximum"), member(rectangle, "yMaximum")];
    }

    function canvasCenterWgs84() {
        var bounds = canvasBoundsWgs84();
        return [(bounds[0] + bounds[2]) / 2, (bounds[1] + bounds[3]) / 2];
    }

    function selectedAreaWkt() {
        if (!projectInfo || !projectInfo.activeLayer) { throw new Error(t("Select polygon features in an active vector layer first.")); }
        var layer = projectInfo.activeLayer;
        var selected;
        try { selected = layer.selectedFeatures(); } catch (firstError) {
            try { selected = layer.selectedFeatures; } catch (secondError) { selected = null; }
        }
        if (!selected || !selected.length) { throw new Error(t("Select one or more polygon features first.")); }
        var parts = [];
        for (var i = 0; i < selected.length; i += 1) {
            var geometry = member(selected[i], "geometry");
            var projected = QfGeometryUtils.reprojectGeometry(geometry, layer.crs, wgs84);
            var wkt = member(projected, "asWkt");
            if (wkt) { parts.push(wkt); }
        }
        if (!parts.length) { throw new Error(t("The selected feature geometry could not be read.")); }
        return GS.mergePolygonWkts(parts);
    }

    function prepareSearchOptions(options) {
        var prepared = {};
        Object.keys(options).forEach(function (key) { prepared[key] = options[key]; });
        prepared.near = canvasCenterWgs84();
        prepared.lang = GS.language();
        if (prepared.useSelectedArea) {
            prepared.area = selectedAreaWkt();
        } else if (prepared.restrictToExtent) {
            prepared.bbox = canvasBoundsWgs84();
        }
        return prepared;
    }

    function search(options) {
        var prepared, payload;
        try {
            prepared = prepareSearchOptions(options);
            payload = GS.buildSearchPayload(prepared.mode, prepared);
        } catch (error) {
            panel.setSearchError(error.message);
            return;
        }
        lastSearchOptions = prepared;
        performSearch(payload);
    }

    function searchPage(pageNumber) {
        if (!lastSearchOptions) { return; }
        var options = {};
        Object.keys(lastSearchOptions).forEach(function (key) { options[key] = lastSearchOptions[key]; });
        options.page = pageNumber;
        lastSearchOptions = options;
        try { performSearch(GS.buildSearchPayload(options.mode, options)); }
        catch (error) { panel.setSearchError(error.message); }
    }

    function performSearch(payload) {
        requestSequence += 1;
        var sequence = requestSequence;
        panel.setSearchLoading();
        clearMapResults();
        request("search", "POST", "/search", payload, function (json) {
            if (sequence !== requestSequence) { return; }
            var page = GS.parseSearchResponse(json);
            resultObjects = page.results;
            panel.setResults(page);
            showResultsOnMap(page.results);
        }, function (message) {
            if (sequence === requestSequence) { panel.setSearchError(message); }
        });
    }

    function startPointSearch(radius) {
        lastSearchOptions = null;
        clearMapResults();
        pointSearchActive = true;
        panel.close();
        toast(t("Tap the map to search what is here."));
        panel.pointRadius = radius;
    }

    function handleMapPoint(screenPoint) {
        var mapPoint = mapCanvas.mapSettings.screenToCoordinate(screenPoint);
        var point = QfGeometryUtils.reprojectPointToWgs84(mapPoint, mapCanvas.mapSettings.destinationCrs);
        pointSearchActive = false;
        panel.openAt(1);
        requestSequence += 1;
        var sequence = requestSequence;
        panel.setSearchLoading();
        request("search", "POST", "/search", GS.buildPointPayload(member(point, "x"), member(point, "y"), panel.pointRadius, GS.language()), function (json) {
            if (sequence !== requestSequence) { return; }
            var page = GS.parseSearchResponse(json);
            page.hasMore = false;
            resultObjects = page.results;
            panel.setResults(page);
            showResultsOnMap(page.results);
        }, function (message) { if (sequence === requestSequence) { panel.setSearchError(message); } });
    }

    function showResultsOnMap(results) {
        if (!results.length) { return; }
        try {
            // A point-only collection works reliably even when the service page
            // contains a mixture of points, lines and polygons.
            var markers = [];
            for (var i = 0; i < results.length; i += 1) {
                var bounds = results[i].bounds;
                markers.push({
                    type: "Feature",
                    properties: { resultIndex: i, title: results[i].title },
                    geometry: { type: "Point", coordinates: [(bounds[0] + bounds[2]) / 2, (bounds[1] + bounds[3]) / 2] }
                });
            }
            var collection = { type: "FeatureCollection", features: markers };
            resultLayer = QfLayerUtils.memoryLayerFromJsonString("GBD search results", JSON.stringify(collection), wgs84);
            if (layerIsValid(resultLayer)) {
                var layers = mapCanvas.mapSettings.layers.slice(0);
                layers.unshift(resultLayer);
                mapCanvas.mapSettings.layers = layers;
                mapCanvas.refresh();
            } else {
                resultLayer = null;
            }
        } catch (error) {
            iface.logMessage("GBD GeoServices: result overlay unavailable: " + error);
        }
    }

    function clearMapResults() {
        if (resultLayer) {
            var layers = mapCanvas.mapSettings.layers.filter(function (layer) { return layer !== resultLayer; });
            mapCanvas.mapSettings.layers = layers;
            resultLayer = null;
        }
        if (geometryHighlighter && geometryHighlighter.geometryWrapper) {
            geometryHighlighter.geometryWrapper.qgsGeometry = QfGeometryUtils.createGeometryFromWkt("GEOMETRYCOLLECTION EMPTY");
        }
        mapCanvas.refresh();
    }

    function clearResults() {
        requestSequence += 1;
        lastSearchOptions = null;
        resultObjects = [];
        clearMapResults();
        panel.clearResults();
    }

    function activateResult(index, keepPanelOpen) {
        var result = resultObjects[index];
        if (!result) { return; }
        try {
            if (result.bounds[0] === result.bounds[2] && result.bounds[1] === result.bounds[3]) {
                var sourcePoint = QfGeometryUtils.point(result.bounds[0], result.bounds[1]);
                var destinationPoint = QfGeometryUtils.reprojectPoint(sourcePoint, wgs84, mapCanvas.mapSettings.destinationCrs);
                mapCanvas.jumpTo(destinationPoint, 15000, 0, true);
            } else {
                var geometry = QfGeometryUtils.createGeometryFromWkt(GS.boundsWkt(result.bounds));
                var rectangle = QfGeometryUtils.boundingBox(geometry);
                var destination = QfGeometryUtils.reprojectRectangle(rectangle, wgs84, mapCanvas.mapSettings.destinationCrs);
                mapCanvas.mapSettings.setExtent(destination, true);
            }
            if (geometryHighlighter && geometryHighlighter.geometryWrapper) {
                var geoJsonLayer = QfLayerUtils.memoryLayerFromJsonString("selected", JSON.stringify({ type: "FeatureCollection", features: [{ type: "Feature", properties: {}, geometry: result.geometry }] }), wgs84);
                if (geoJsonLayer) {
                    var iterator = QfLayerUtils.createFeatureIterator(geoJsonLayer);
                    if (iterator.hasNext()) {
                        var feature = iterator.next();
                        geometryHighlighter.geometryWrapper.qgsGeometry = member(feature, "geometry");
                        geometryHighlighter.geometryWrapper.crs = wgs84;
                    }
                }
            }
            if (!keepPanelOpen) { panel.close(); }
            mapCanvas.refresh();
        } catch (error) {
            toast(t("Could not navigate to the selected result."));
        }
    }

    function resultAtScreenPoint(screenPoint) {
        if (!resultObjects.length) { return -1; }
        var topLeft = mapCanvas.mapSettings.screenToCoordinate(Qt.point(screenPoint.x - 16, screenPoint.y - 16));
        var bottomRight = mapCanvas.mapSettings.screenToCoordinate(Qt.point(screenPoint.x + 16, screenPoint.y + 16));
        var hitRectangle = QfGeometryUtils.createRectangleFromPoints(topLeft, bottomRight);
        var wgsRectangle = QfGeometryUtils.reprojectRectangle(hitRectangle, mapCanvas.mapSettings.destinationCrs, wgs84);
        var west = member(wgsRectangle, "xMinimum"), south = member(wgsRectangle, "yMinimum");
        var east = member(wgsRectangle, "xMaximum"), north = member(wgsRectangle, "yMaximum");
        for (var i = 0; i < resultObjects.length; i += 1) {
            var bounds = resultObjects[i].bounds;
            var centerX = (bounds[0] + bounds[2]) / 2;
            var centerY = (bounds[1] + bounds[3]) / 2;
            if (centerX >= west && centerX <= east && centerY >= south && centerY <= north) { return i; }
        }
        return -1;
    }

    function addBasemap(theme, imageFormat, replaceExisting) {
        try {
            if (basemapLayer && !replaceExisting) {
                panel.setMapError(t("A GBD basemap is already active. Enable replacement or remove it first."));
                return;
            }
            var generation = generations[theme] || 0;
            var url = GS.buildXyzUrl(settings.baseUrl, theme, imageFormat, generation);
            var uri = GS.buildXyzProviderUri(url, settings.authcfg, settings.apiKey);
            var layer = QfLayerUtils.loadRasterLayer(uri, "OSM — " + GS.displayThemeName(theme), "wms");
            if (!layerIsValid(layer)) { throw new Error(t("QField could not create the XYZ layer.")); }
            var layers = mapCanvas.mapSettings.layers.filter(function (candidate) { return candidate !== basemapLayer; });
            // QgsMapSettings stores index 0 as the topmost rendered layer.
            // A session basemap must be visible immediately because QField's
            // plugin API does not add it to the interactive layer tree.
            layers.unshift(layer);
            basemapLayer = layer;
            mapCanvas.mapSettings.layers = layers;
            iface.logMessage("GBD GeoServices: session basemap is topmost; canvas layer count=" + layers.length);
            mapCanvas.refresh();
            if (metadata && metadata.bounds) { zoomToServiceBounds(); }
            panel.setMapSuccess(t("Basemap added for this QField session."));
            toast(t("Basemap added for this QField session."));
            panel.close();
        } catch (error) {
            panel.setMapError(t("Could not add the basemap.") + " " + error.message);
        }
    }

    function zoomToServiceBounds() {
        if (!metadata) { return; }
        var geometry = QfGeometryUtils.createGeometryFromWkt(GS.boundsWkt(metadata.bounds));
        var extent = QfGeometryUtils.reprojectRectangle(QfGeometryUtils.boundingBox(geometry), wgs84, mapCanvas.mapSettings.destinationCrs);
        mapCanvas.mapSettings.setExtent(extent, true);
        mapCanvas.refresh();
    }

    Component.onCompleted: {
        GS.setLanguage(Qt.locale().name);
        iface.addItemToPluginsToolbar(toolbarButton);
        if (pointHandler) {
            pointHandler.registerHandler("gbd_geoservices_point", function (point, type, interactionType) {
                if (interactionType === "clicked") {
                    if (pointSearchActive) {
                        handleMapPoint(point);
                        return true;
                    }
                    var resultIndex = resultAtScreenPoint(point);
                    if (resultIndex >= 0) {
                        activateResult(resultIndex, true);
                        panel.openAt(1);
                        panel.selectResult(resultIndex);
                        return true;
                    }
                }
                return false;
            });
        }
        refreshCatalog();
    }

    Component.onDestruction: {
        if (pointHandler) { pointHandler.deregisterHandler("gbd_geoservices_point"); }
        clearMapResults();
    }

    QfToolButton {
        id: toolbarButton
        width: 48
        height: 48
        iconSource: Qt.resolvedUrl("icon.svg")
        iconColor: "transparent"
        bgcolor: "#FFFFFF"
        round: true
        onClicked: plugin.openPanel()
    }

    GeoServicesDialog {
        id: panel
        parent: mainWindow.contentItem
        baseUrl: settings.baseUrl
        apiKey: settings.apiKey
        authcfg: settings.authcfg
        onRefreshRequested: plugin.refreshCatalog()
        onSettingsSaveRequested: function (baseUrl, apiKey, authcfg) { plugin.saveSettings(baseUrl, apiKey, authcfg); }
        onSearchRequested: function (options) { plugin.search(options); }
        onPageRequested: function (page) { plugin.searchPage(page); }
        onPointSearchRequested: function (radius) { plugin.startPointSearch(radius); }
        onClearRequested: plugin.clearResults()
        onResultActivated: function (index) { plugin.activateResult(index, false); }
        onAddBasemapRequested: function (theme, format, replaceExisting) { plugin.addBasemap(theme, format, replaceExisting); }
        onZoomToCoverageRequested: plugin.zoomToServiceBounds()
    }
}
