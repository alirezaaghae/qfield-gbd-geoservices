import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import Theme

import "js/geoservices.js" as GS

Popup {
    id: dialog
    modal: true
    dim: false
    focus: true
    padding: 0
    closePolicy: Popup.CloseOnEscape | Popup.CloseOnPressOutside

    // Behave like QField's side panels: use the full width only on narrow
    // phones, while keeping the map visible on tablets and desktops.
    readonly property real viewportWidth: parent ? parent.width : 480
    readonly property real viewportHeight: parent ? parent.height : 720
    readonly property int topSafeInset: Qt.platform.os === "ios" ? 32 : 12
    readonly property int bottomSafeInset: Qt.platform.os === "ios" ? 16 : 12
    readonly property real restingX: Math.max(0, viewportWidth - width)
    width: Math.min(viewportWidth, Math.min(520, Math.max(360, viewportWidth * 0.46)))
    height: viewportHeight
    x: restingX
    y: 0

    enter: Transition {
        NumberAnimation {
            property: "x"
            from: dialog.viewportWidth
            to: dialog.restingX
            duration: 220
            easing.type: Easing.OutCubic
        }
    }
    exit: Transition {
        NumberAnimation {
            property: "x"
            from: dialog.restingX
            to: dialog.viewportWidth
            duration: 180
            easing.type: Easing.InCubic
        }
    }

    readonly property color brand: "#0877C9"
    readonly property color brandDark: "#075B9A"
    readonly property color canvasColor: "#F3F6F9"
    readonly property color surfaceColor: "#FFFFFF"
    readonly property color textColor: "#172033"
    readonly property color mutedColor: "#64748B"
    readonly property color borderColor: "#DCE4EC"
    readonly property color successColor: "#15803D"
    readonly property color dangerColor: "#C62828"
    readonly property int contentMaxWidth: 980

    palette.window: canvasColor
    palette.windowText: textColor
    palette.base: surfaceColor
    palette.alternateBase: canvasColor
    palette.text: textColor
    palette.button: surfaceColor
    palette.buttonText: textColor
    palette.highlight: brand
    palette.highlightedText: "#FFFFFF"
    palette.placeholderText: mutedColor
    palette.mid: borderColor

    property string baseUrl: ""
    property string apiKey: ""
    property int pointRadius: 0
    property var currentPage: null
    property var currentResults: []
    property var metadata: null
    property bool catalogBusy: false
    property bool searchBusy: false

    signal refreshRequested()
    signal settingsSaveRequested(string baseUrl, string apiKey)
    signal searchRequested(var options)
    signal pageRequested(int page)
    signal pointSearchRequested(int radius)
    signal clearRequested()
    signal resultActivated(int index)
    signal addBasemapRequested(string theme, string imageFormat, bool replaceExisting)
    signal zoomToCoverageRequested()

    component UiLabel: Label {
        color: dialog.textColor
        wrapMode: Text.Wrap
    }

    component FieldLabel: Label {
        color: dialog.textColor
        font.pixelSize: 13
        font.weight: Font.DemiBold
    }

    component UiButton: Button {
        id: buttonControl
        property bool primary: false
        implicitHeight: 46
        leftPadding: 18
        rightPadding: 18
        contentItem: Label {
            text: buttonControl.text
            color: buttonControl.enabled ? (buttonControl.primary ? "#FFFFFF" : dialog.textColor) : dialog.mutedColor
            font.pixelSize: 14
            font.weight: Font.DemiBold
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
            elide: Text.ElideRight
        }
        background: Rectangle {
            radius: 9
            color: !buttonControl.enabled ? "#E9EEF3" : buttonControl.down ? (buttonControl.primary ? dialog.brandDark : "#E8EEF4") : (buttonControl.primary ? dialog.brand : dialog.surfaceColor)
            border.width: buttonControl.primary ? 0 : 1
            border.color: dialog.borderColor
        }
    }

    component UiField: TextField {
        implicitHeight: 46
        color: dialog.textColor
        placeholderTextColor: dialog.mutedColor
        selectionColor: dialog.brand
        selectedTextColor: "#FFFFFF"
        leftPadding: 13
        rightPadding: 13
        background: Rectangle {
            radius: 8
            color: dialog.surfaceColor
            border.width: parent.activeFocus ? 2 : 1
            border.color: parent.activeFocus ? dialog.brand : dialog.borderColor
        }
    }

    component UiCombo: ComboBox {
        implicitHeight: 46
        leftPadding: 13
        rightPadding: 38
        palette.text: dialog.textColor
        palette.buttonText: dialog.textColor
        palette.highlight: dialog.brand
        palette.highlightedText: "#FFFFFF"
        background: Rectangle {
            radius: 8
            color: dialog.surfaceColor
            border.width: parent.activeFocus ? 2 : 1
            border.color: parent.activeFocus ? dialog.brand : dialog.borderColor
        }
    }

    function t(source, values) { return GS.tr(source, values); }
    function openAt(index) { tabs.currentIndex = index; open(); }

    function setCatalogLoading() {
        catalogBusy = true;
        mapStatus.text = t("Loading styles and service metadata…");
        mapStatus.color = mutedColor;
    }

    function setMetadata(value) {
        catalogBusy = false;
        metadata = value;
        themeModel.clear();
        value.themes.forEach(function (theme) { themeModel.append({ themeId: theme.id, label: GS.displayThemeName(theme.id), paletteName: theme.palette, detailName: theme.detail }); });
        formatModel.clear();
        value.formats.forEach(function (format) { formatModel.append({ value: format, label: format.toUpperCase() }); });
        filterCategories(categoryFilter.text);
        mapStatus.text = apiKey.trim().length === 0
            ? t("Enter and save an API key before adding a basemap.")
            : t("{styles} styles and {formats} image formats available.", { styles: value.themes.length, formats: value.formats.length });
        mapStatus.color = apiKey.trim().length === 0 ? dangerColor : successColor;
        metadataSummary.text = [
            t("API version") + ": " + (value.version || "—"),
            t("Coverage") + ": " + (value.area || "—"),
            t("Data date") + ": " + (value.date || "—"),
            t("Categories") + ": " + value.categories.length,
            t("Attribution") + ": " + (value.attribution || "—")
        ].join("\n");
    }

    function setCatalogError(message) { catalogBusy = false; mapStatus.text = message + " " + t("Open Settings to verify the connection."); mapStatus.color = dangerColor; }
    function setServiceStatus(raw, generationCount) { connectionStatus.text = t("Connection successful. {count} style generations loaded.", { count: generationCount }); connectionStatus.color = successColor; serviceDetails.text = raw ? JSON.stringify(raw, null, 2) : ""; }
    function setServiceError(message) { connectionStatus.text = message; connectionStatus.color = dangerColor; }
    function setSettingsError(message) { settingsStatus.text = message; settingsStatus.color = dangerColor; }
    function setSettingsSaved() { settingsStatus.text = t("Settings saved. Testing the connection…"); settingsStatus.color = brand; }
    function setMapSuccess(message) { mapStatus.text = message; mapStatus.color = successColor; }
    function setMapError(message) { mapStatus.text = message; mapStatus.color = dangerColor; }

    function setSearchLoading() {
        searchBusy = true;
        searchStatus.text = t("Searching…");
        searchStatus.color = mutedColor;
        resultsModel.clear();
        currentResults = [];
        currentPage = null;
    }

    function setResults(page) {
        searchBusy = false;
        currentPage = page;
        currentResults = page.results;
        resultsModel.clear();
        page.results.forEach(function (result) { resultsModel.append({ title: result.title, subtitle: result.subtitle, featureId: result.id === undefined ? "" : String(result.id), geometryType: result.geometry.type }); });
        searchStatus.text = page.total === 0 ? t("No results. Try a broader query, another category, or higher fuzziness.") : t("{total} results · showing {count}", { total: page.total, count: page.count });
        searchStatus.color = page.total === 0 ? mutedColor : successColor;
        interpretation.text = page.interpretation ? t("Interpreted as: {value}", { value: typeof page.interpretation === "string" ? page.interpretation : JSON.stringify(page.interpretation) }) : "";
    }

    function setSearchError(message) { searchBusy = false; searchStatus.text = message; searchStatus.color = dangerColor; }
    function clearResults() { searchBusy = false; currentPage = null; currentResults = []; resultsModel.clear(); searchStatus.text = t("Enter a search term or choose a category."); searchStatus.color = mutedColor; interpretation.text = ""; }
    function selectResult(index) { resultList.currentIndex = index; resultList.positionViewAtIndex(index, ListView.Center); }
    function selectedCategoryId() { return categoryBox.currentIndex >= 0 ? categoryModel.get(categoryBox.currentIndex).categoryId : ""; }

    function filterCategories(term) {
        var query = String(term || "").trim().toLowerCase();
        categoryModel.clear();
        categoryModel.append({ categoryId: "", label: t("All categories") });
        if (!metadata) { return; }
        metadata.categories.forEach(function (category) { if (!query || category.path.toLowerCase().indexOf(query) >= 0) { categoryModel.append({ categoryId: category.id, label: category.path }); } });
        categoryBox.currentIndex = 0;
    }

    function collectSearchOptions(page) {
        return {
            mode: ["name", "address", "phrase"][modeBox.currentIndex], query: queryField.text,
            street: streetField.text, housenumber: numberField.text, postcode: postcodeField.text, city: cityField.text,
            category: selectedCategoryId(), page: page, limit: 20,
            sort: ["relevance", "distance", "name", "address"][sortBox.currentIndex], similarity: Math.round(fuzziness.value),
            restrictToExtent: extentCheck.checked, useSelectedArea: selectionCheck.checked, within: withinCheck.checked
        };
    }

    background: Rectangle { color: dialog.canvasColor }

    ColumnLayout {
        anchors.fill: parent
        spacing: 0

        Rectangle {
            Layout.fillWidth: true
            Layout.preferredHeight: 72 + dialog.topSafeInset
            color: dialog.brandDark
            RowLayout {
                width: Math.min(dialog.contentMaxWidth, parent.width - 32)
                height: 72
                anchors.bottom: parent.bottom
                anchors.horizontalCenter: parent.horizontalCenter
                spacing: 12
                Rectangle {
                    Layout.preferredWidth: 46
                    Layout.preferredHeight: 46
                    radius: 11
                    color: "#FFFFFF"
                    Image {
                        anchors.fill: parent
                        anchors.margins: 6
                        source: Qt.resolvedUrl("icon.svg")
                        sourceSize.width: 34
                        sourceSize.height: 34
                        fillMode: Image.PreserveAspectFit
                    }
                }
                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 1
                    Label { text: "GBD GeoServices"; color: "#FFFFFF"; font.pixelSize: 19; font.weight: Font.DemiBold }
                    Label { text: t("Maps and place search"); color: "#D8ECFA"; font.pixelSize: 12 }
                }
                ToolButton {
                    id: closeButton
                    Layout.preferredWidth: 42; Layout.preferredHeight: 42
                    text: "×"; Accessible.name: t("Close")
                    contentItem: Label {
                        text: closeButton.text
                        color: "#FFFFFF"
                        font.pixelSize: 27
                        font.weight: Font.Medium
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                    background: Rectangle { radius: 9; color: closeButton.down ? "#40FFFFFF" : "#20FFFFFF" }
                    onClicked: dialog.close()
                }
            }
        }

        Rectangle {
            Layout.fillWidth: true
            Layout.preferredHeight: 58
            color: dialog.surfaceColor
            border.width: 1; border.color: dialog.borderColor
            TabBar {
                id: tabs
                width: Math.min(720, parent.width - 24); height: 48; anchors.centerIn: parent; spacing: 6
                background: Rectangle { color: "transparent" }
                TabButton {
                    id: mapsTab
                    text: t("Maps")
                    contentItem: Label { text: mapsTab.text; color: mapsTab.checked ? dialog.brandDark : dialog.mutedColor; font.weight: mapsTab.checked ? Font.DemiBold : Font.Medium; horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter }
                    background: Rectangle { radius: 9; color: mapsTab.checked ? "#E8F3FB" : "transparent" }
                }
                TabButton {
                    id: searchTab
                    text: t("Search")
                    contentItem: Label { text: searchTab.text; color: searchTab.checked ? dialog.brandDark : dialog.mutedColor; font.weight: searchTab.checked ? Font.DemiBold : Font.Medium; horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter }
                    background: Rectangle { radius: 9; color: searchTab.checked ? "#E8F3FB" : "transparent" }
                }
                TabButton {
                    id: settingsTab
                    text: t("Settings")
                    contentItem: Label { text: settingsTab.text; color: settingsTab.checked ? dialog.brandDark : dialog.mutedColor; font.weight: settingsTab.checked ? Font.DemiBold : Font.Medium; horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter }
                    background: Rectangle { radius: 9; color: settingsTab.checked ? "#E8F3FB" : "transparent" }
                }
            }
        }

        StackLayout {
            currentIndex: tabs.currentIndex
            Layout.fillWidth: true
            Layout.fillHeight: true

            ScrollView {
                id: mapsScroll
                contentWidth: availableWidth
                clip: true
                background: Rectangle { color: dialog.canvasColor }
                ColumnLayout {
                    width: Math.min(dialog.contentMaxWidth, mapsScroll.availableWidth - 32)
                    x: Math.max(16, (mapsScroll.availableWidth - width) / 2)
                    spacing: 14
                    Item { Layout.preferredHeight: 8 }
                    Rectangle {
                        Layout.fillWidth: true
                        implicitHeight: mapsCardContent.implicitHeight + 44
                        radius: 14; color: dialog.surfaceColor; border.width: 1; border.color: dialog.borderColor
                        ColumnLayout {
                            id: mapsCardContent
                            anchors.fill: parent; anchors.margins: 22; spacing: 14
                            UiLabel { text: t("Basemap"); font.pixelSize: 21; font.weight: Font.DemiBold }
                            UiLabel { Layout.fillWidth: true; color: dialog.mutedColor; text: t("Choose a live style from the GeoServices catalog. The layer stays active for this QField session; save permanent basemaps in the QGIS project.") }
                            GridLayout {
                                Layout.fillWidth: true; columns: width >= 640 ? 2 : 1; columnSpacing: 14; rowSpacing: 7
                                ColumnLayout {
                                    Layout.fillWidth: true
                                    FieldLabel { text: t("Style") }
                                    UiCombo {
                                        id: themeBox
                                        Layout.fillWidth: true
                                        textRole: "label"
                                        model: ListModel { id: themeModel }
                                        enabled: count > 0 && !catalogBusy
                                    }
                                }
                                ColumnLayout {
                                    Layout.fillWidth: true
                                    FieldLabel { text: t("Image format") }
                                    UiCombo {
                                        id: formatBox
                                        Layout.fillWidth: true
                                        textRole: "label"
                                        model: ListModel { id: formatModel }
                                        enabled: count > 0 && !catalogBusy
                                    }
                                }
                            }
                            CheckBox { id: replaceBasemapCheck; text: t("Replace the active GBD basemap"); checked: true; implicitHeight: 42; palette.windowText: dialog.textColor }
                            RowLayout {
                                Layout.fillWidth: true; spacing: 10
                                UiButton { text: t("Refresh"); Layout.fillWidth: true; enabled: !catalogBusy; onClicked: dialog.refreshRequested() }
                                UiButton { text: t("Add to map"); primary: true; Layout.fillWidth: true; enabled: dialog.apiKey.trim().length > 0 && themeBox.currentIndex >= 0 && formatBox.currentIndex >= 0 && !catalogBusy; onClicked: dialog.addBasemapRequested(themeModel.get(themeBox.currentIndex).themeId, formatModel.get(formatBox.currentIndex).value, replaceBasemapCheck.checked) }
                            }
                            UiButton { text: t("Zoom to service coverage"); Layout.fillWidth: true; enabled: metadata !== null; onClicked: dialog.zoomToCoverageRequested() }
                        }
                    }
                    Rectangle {
                        Layout.fillWidth: true; implicitHeight: Math.max(54, mapStatus.implicitHeight + 28); radius: 10; color: dialog.surfaceColor; border.width: 1; border.color: dialog.borderColor
                        RowLayout {
                            anchors.fill: parent; anchors.margins: 14; spacing: 10
                            BusyIndicator { running: catalogBusy; visible: running; Layout.preferredWidth: 24; Layout.preferredHeight: 24 }
                            UiLabel { id: mapStatus; Layout.fillWidth: true; color: dialog.mutedColor; text: t("Refresh to load available map styles.") }
                        }
                    }
                    Item { Layout.preferredHeight: 18 + dialog.bottomSafeInset }
                }
            }

            ScrollView {
                id: searchScroll
                contentWidth: availableWidth
                clip: true
                background: Rectangle { color: dialog.canvasColor }
                ColumnLayout {
                    width: Math.min(dialog.contentMaxWidth, searchScroll.availableWidth - 32)
                    x: Math.max(16, (searchScroll.availableWidth - width) / 2)
                    spacing: 14
                    Item { Layout.preferredHeight: 8 }
                    Rectangle {
                        Layout.fillWidth: true
                        implicitHeight: searchCardContent.implicitHeight + 44
                        radius: 14; color: dialog.surfaceColor; border.width: 1; border.color: dialog.borderColor
                        ColumnLayout {
                            id: searchCardContent
                            anchors.fill: parent; anchors.margins: 22; spacing: 11
                            UiLabel { text: t("Find places"); font.pixelSize: 21; font.weight: Font.DemiBold }
                            UiCombo { id: modeBox; Layout.fillWidth: true; model: [t("Name"), t("Address"), t("Free text")] }
                            UiField { id: queryField; Layout.fillWidth: true; visible: modeBox.currentIndex !== 1; placeholderText: modeBox.currentIndex === 0 ? t("e.g. Rathaus") : t("name, category, place, or any mix"); inputMethodHints: Qt.ImhNoPredictiveText; onAccepted: dialog.searchRequested(dialog.collectSearchOptions(0)) }
                            ColumnLayout {
                                Layout.fillWidth: true; visible: modeBox.currentIndex === 1; spacing: 9
                                UiField { id: streetField; Layout.fillWidth: true; placeholderText: t("Street") }
                                RowLayout {
                                    Layout.fillWidth: true; spacing: 9
                                    UiField { id: numberField; Layout.preferredWidth: 130; placeholderText: t("Number") }
                                    UiField { id: postcodeField; Layout.fillWidth: true; placeholderText: t("Postcode (optional)"); inputMethodHints: Qt.ImhDigitsOnly }
                                }
                                UiField { id: cityField; Layout.fillWidth: true; placeholderText: t("City (optional)") }
                            }
                            GridLayout {
                                Layout.fillWidth: true; columns: width >= 640 ? 2 : 1; columnSpacing: 12; rowSpacing: 7
                                ColumnLayout {
                                    Layout.fillWidth: true
                                    FieldLabel { text: t("Category") }
                                    UiField { id: categoryFilter; Layout.fillWidth: true; placeholderText: t("Filter categories…"); onTextChanged: dialog.filterCategories(text) }
                                }
                                ColumnLayout {
                                    Layout.fillWidth: true
                                    FieldLabel { text: t("Category") }
                                    UiCombo { id: categoryBox; Layout.fillWidth: true; textRole: "label"; model: ListModel { id: categoryModel; ListElement { categoryId: ""; label: "All categories" } } }
                                }
                            }
                            UiButton { id: advancedButton; Layout.fillWidth: true; text: advanced.visible ? t("Hide search options") : t("More search options"); onClicked: advanced.visible = !advanced.visible }
                            Rectangle {
                                Layout.fillWidth: true; implicitHeight: advanced.visible ? advanced.implicitHeight + 28 : 0; visible: advanced.visible; radius: 10; color: "#F7F9FB"; border.width: 1; border.color: dialog.borderColor
                                ColumnLayout {
                                    id: advanced
                                    anchors.fill: parent; anchors.margins: 14; visible: false; spacing: 8
                                    FieldLabel { text: t("Sort order") }
                                    UiCombo { id: sortBox; Layout.fillWidth: true; model: [t("Relevance"), t("Distance"), t("Name"), t("Address")] }
                                    RowLayout {
                                        Layout.fillWidth: true
                                        UiLabel { text: t("Fuzziness") + ": " + Math.round(fuzziness.value); font.weight: Font.DemiBold }
                                        Slider { id: fuzziness; Layout.fillWidth: true; from: 1; to: 10; stepSize: 1; value: 4 }
                                    }
                                    CheckBox { id: extentCheck; text: t("Only in the current view"); implicitHeight: 40; enabled: !selectionCheck.checked; palette.windowText: dialog.textColor }
                                    CheckBox { id: selectionCheck; text: t("Use selected feature(s) as search area"); implicitHeight: 40; palette.windowText: dialog.textColor; onToggled: if (checked) { extentCheck.checked = false; withinCheck.checked = true; } }
                                    CheckBox { id: withinCheck; text: t("Results must be entirely inside the selected shape"); implicitHeight: 40; enabled: selectionCheck.checked; palette.windowText: dialog.textColor }
                                }
                            }
                            RowLayout {
                                Layout.fillWidth: true; spacing: 10
                                UiButton { text: t("Search"); primary: true; Layout.fillWidth: true; enabled: !searchBusy; onClicked: dialog.searchRequested(dialog.collectSearchOptions(0)) }
                                UiButton { text: t("Clear"); Layout.preferredWidth: 120; enabled: !searchBusy; onClicked: { queryField.clear(); streetField.clear(); numberField.clear(); postcodeField.clear(); cityField.clear(); dialog.clearRequested(); } }
                            }
                        }
                    }
                    Rectangle {
                        Layout.fillWidth: true; implicitHeight: pointCardContent.implicitHeight + 36; radius: 14; color: dialog.surfaceColor; border.width: 1; border.color: dialog.borderColor
                        ColumnLayout {
                            id: pointCardContent
                            anchors.fill: parent; anchors.margins: 18; spacing: 10
                            UiLabel { text: t("What's here?"); font.pixelSize: 17; font.weight: Font.DemiBold }
                            RowLayout {
                                Layout.fillWidth: true; spacing: 10
                                SpinBox { id: radiusBox; Layout.fillWidth: true; implicitHeight: 46; from: 0; to: 10000; stepSize: 50; value: 0; editable: true; palette.text: dialog.textColor; palette.buttonText: dialog.textColor; textFromValue: function (value) { return value === 0 ? t("Automatic radius") : value + " m"; }; valueFromText: function (text) { var parsed = parseInt(String(text).replace(/[^0-9]/g, ""), 10); return isNaN(parsed) ? 0 : parsed; } }
                                UiButton { text: t("Pick on map"); primary: true; onClicked: dialog.pointSearchRequested(radiusBox.value) }
                            }
                        }
                    }
                    Rectangle {
                        Layout.fillWidth: true; implicitHeight: resultsContent.implicitHeight + 36; radius: 14; color: dialog.surfaceColor; border.width: 1; border.color: dialog.borderColor
                        ColumnLayout {
                            id: resultsContent
                            anchors.fill: parent; anchors.margins: 18; spacing: 8
                            RowLayout {
                                Layout.fillWidth: true
                                BusyIndicator { running: searchBusy; visible: running; Layout.preferredWidth: 24; Layout.preferredHeight: 24 }
                                UiLabel { id: searchStatus; Layout.fillWidth: true; color: dialog.mutedColor; text: t("Enter a search term or choose a category.") }
                            }
                            UiLabel { id: interpretation; Layout.fillWidth: true; color: dialog.mutedColor; font.italic: true; visible: text.length > 0 }
                            ListView {
                                id: resultList
                                Layout.fillWidth: true; Layout.preferredHeight: Math.min(contentHeight, dialog.height * 0.42); implicitHeight: contentHeight; interactive: contentHeight > height; clip: true
                                model: ListModel { id: resultsModel }
                                spacing: 6
                                delegate: ItemDelegate {
                                    id: resultDelegate
                                    width: resultList.width; implicitHeight: Math.max(72, resultColumn.implicitHeight + 22)
                                    property bool detailsVisible: false
                                    Accessible.name: model.title + (model.subtitle ? ", " + model.subtitle : "")
                                    onClicked: dialog.resultActivated(index)
                                    background: Rectangle { radius: 9; color: resultDelegate.highlighted ? "#E8F3FB" : "#F7F9FB"; border.width: 1; border.color: dialog.borderColor }
                                    contentItem: ColumnLayout {
                                        id: resultColumn; spacing: 3
                                        Label { Layout.fillWidth: true; text: model.title; color: dialog.textColor; font.weight: Font.DemiBold; wrapMode: Text.Wrap }
                                        Label { Layout.fillWidth: true; text: model.subtitle; color: dialog.mutedColor; wrapMode: Text.Wrap; visible: text.length > 0 }
                                        Label { text: model.geometryType + (model.featureId ? " · " + model.featureId : ""); color: dialog.mutedColor; font.pixelSize: 11 }
                                        UiButton { text: resultDelegate.detailsVisible ? t("Hide details") : t("Details"); implicitHeight: 36; onClicked: resultDelegate.detailsVisible = !resultDelegate.detailsVisible }
                                        Label { Layout.fillWidth: true; visible: resultDelegate.detailsVisible; color: dialog.textColor; text: visible && dialog.currentResults[index] ? JSON.stringify(dialog.currentResults[index].properties, null, 2) : ""; font.family: "monospace"; font.pixelSize: 11; wrapMode: Text.WrapAnywhere }
                                    }
                                }
                            }
                            RowLayout {
                                Layout.fillWidth: true; visible: currentPage !== null
                                UiButton { text: t("Previous"); enabled: currentPage && currentPage.page > 0 && !searchBusy; onClicked: dialog.pageRequested(currentPage.page - 1) }
                                UiLabel { Layout.fillWidth: true; horizontalAlignment: Text.AlignHCenter; text: currentPage ? t("Page {page}", { page: currentPage.page + 1 }) : "" }
                                UiButton { text: t("Next"); enabled: currentPage && currentPage.hasMore && !searchBusy; onClicked: dialog.pageRequested(currentPage.page + 1) }
                            }
                        }
                    }
                    Item { Layout.preferredHeight: 18 + dialog.bottomSafeInset }
                }
            }

            ScrollView {
                id: settingsScroll
                contentWidth: availableWidth
                clip: true
                background: Rectangle { color: dialog.canvasColor }
                ColumnLayout {
                    width: Math.min(dialog.contentMaxWidth, settingsScroll.availableWidth - 32)
                    x: Math.max(16, (settingsScroll.availableWidth - width) / 2)
                    spacing: 14
                    Item { Layout.preferredHeight: 8 }
                    Rectangle {
                        Layout.fillWidth: true; implicitHeight: settingsCardContent.implicitHeight + 44; radius: 14; color: dialog.surfaceColor; border.width: 1; border.color: dialog.borderColor
                        ColumnLayout {
                            id: settingsCardContent
                            anchors.fill: parent; anchors.margins: 22; spacing: 10
                            UiLabel { text: t("Service connection"); font.pixelSize: 21; font.weight: Font.DemiBold }
                            FieldLabel { text: t("Base URL") }
                            UiField { id: baseUrlField; Layout.fillWidth: true; text: dialog.baseUrl; placeholderText: "https://…"; inputMethodHints: Qt.ImhUrlCharactersOnly }
                            FieldLabel { text: t("API key") }
                            UiField { id: apiKeyField; Layout.fillWidth: true; text: dialog.apiKey; echoMode: showKey.checked ? TextInput.Normal : TextInput.Password; placeholderText: t("Bearer token for API requests") }
                            CheckBox { id: showKey; text: t("Show API key"); implicitHeight: 40; palette.windowText: dialog.textColor }
                            UiLabel { Layout.fillWidth: true; color: dialog.mutedColor; font.pixelSize: 12; text: t("The API key is empty on a new installation and remains saved on this device after you tap Save and test.") }
                            RowLayout {
                                Layout.fillWidth: true; spacing: 10
                                UiButton { text: t("Save and test"); primary: true; Layout.fillWidth: true; onClicked: dialog.settingsSaveRequested(baseUrlField.text, apiKeyField.text) }
                                UiButton { text: t("Test again"); Layout.fillWidth: true; onClicked: dialog.refreshRequested() }
                            }
                            UiLabel { id: settingsStatus; Layout.fillWidth: true }
                            UiLabel { id: connectionStatus; Layout.fillWidth: true; color: dialog.mutedColor; text: t("Not tested yet.") }
                        }
                    }
                    Rectangle {
                        Layout.fillWidth: true; implicitHeight: metadataCardContent.implicitHeight + 40; radius: 14; color: dialog.surfaceColor; border.width: 1; border.color: dialog.borderColor
                        ColumnLayout {
                            id: metadataCardContent
                            anchors.fill: parent; anchors.margins: 20; spacing: 10
                            UiLabel { text: t("Service metadata"); font.pixelSize: 18; font.weight: Font.DemiBold }
                            UiLabel { id: metadataSummary; Layout.fillWidth: true; color: dialog.mutedColor; text: t("Refresh to load metadata.") }
                            UiButton { text: serviceDetails.visible ? t("Hide technical status") : t("Show technical status"); Layout.fillWidth: true; onClicked: serviceDetails.visible = !serviceDetails.visible }
                            Label { id: serviceDetails; Layout.fillWidth: true; visible: false; color: dialog.textColor; wrapMode: Text.WrapAnywhere; font.family: "monospace"; font.pixelSize: 11 }
                        }
                    }
                    Item { Layout.preferredHeight: 18 + dialog.bottomSafeInset }
                }
            }
        }
    }
}
