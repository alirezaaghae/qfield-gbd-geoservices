.pragma library

// Dependency-free GeoServices API 0.3 helpers.  This file deliberately contains
// no QML/QField objects so the contract can be tested with Node.js.

var SEARCH_MODES = { name: true, address: true, phrase: true };
var SORT_ORDERS = { relevance: true, distance: true, name: true, address: true };
var _language = "en";

var DE = {
    "A GBD basemap is already active. Enable replacement or remove it first.": "Eine GBD-Hintergrundkarte ist bereits aktiv. Ersetzen aktivieren oder sie zuerst entfernen.",
    "API key": "API-Schlüssel",
    "API version": "API-Version",
    "Add to map": "Zur Karte hinzufügen",
    "Address": "Adresse",
    "All categories": "Alle Kategorien",
    "Attribution": "Quellenangabe",
    "Authentication failed. Check the API key.": "Authentifizierung fehlgeschlagen. API-Schlüssel prüfen.",
    "Automatic radius": "Automatischer Radius",
    "Base URL": "Basis-URL",
    "Basemap": "Hintergrundkarte",
    "Basemap added for this QField session.": "Hintergrundkarte für diese QField-Sitzung hinzugefügt.",
    "Bearer token for API requests": "Bearer-Token für API-Anfragen",
    "Categories": "Kategorien",
    "Category": "Kategorie",
    "Choose a live style from the GeoServices catalog. The layer stays active for this QField session; save permanent basemaps in the QGIS project.": "Einen aktuellen Stil aus dem GeoServices-Katalog wählen. Die Ebene bleibt für diese QField-Sitzung aktiv; dauerhafte Hintergrundkarten im QGIS-Projekt speichern.",
    "City (optional)": "Ort (optional)",
    "Clear": "Leeren",
    "Close": "Schließen",
    "Connection successful. {count} style generations loaded.": "Verbindung erfolgreich. {count} Stilgenerationen geladen.",
    "Could not add the basemap.": "Die Hintergrundkarte konnte nicht hinzugefügt werden.",
    "Could not navigate to the selected result.": "Zum ausgewählten Treffer konnte nicht navigiert werden.",
    "Coverage": "Abdeckung",
    "Data date": "Datenstand",
    "Details": "Details",
    "Default": "Standard",
    "Dark": "Dunkel",
    "Distance": "Entfernung",
    "Enter a query or select a category.": "Suchbegriff eingeben oder Kategorie auswählen.",
    "Enter and save an API key before adding a basemap.": "Vor dem Hinzufügen einer Hintergrundkarte einen API-Schlüssel eingeben und speichern.",
    "Enter a search term or choose a category.": "Suchbegriff eingeben oder Kategorie auswählen.",
    "Find places": "Orte finden",
    "Filter categories…": "Kategorien filtern…",
    "Free text": "Freitext",
    "Fuzziness": "Unschärfe",
    "High contrast": "Hoher Kontrast",
    "Hide search options": "Suchoptionen ausblenden",
    "Hide details": "Details ausblenden",
    "Hide technical status": "Technischen Status ausblenden",
    "Image format": "Bildformat",
    "Interpreted as: {value}": "Interpretiert als: {value}",
    "Invalid search page or limit.": "Ungültige Suchseite oder Trefferanzahl.",
    "Light": "Hell",
    "Loading styles and service metadata…": "Stile und Service-Metadaten werden geladen…",
    "Maps": "Karten",
    "Maps and place search": "Karten und Ortssuche",
    "Maximum": "Maximum",
    "Minimum": "Minimum",
    "More search options": "Weitere Suchoptionen",
    "Name": "Name",
    "Network request failed. Check connectivity and the service URL.": "Netzwerkanfrage fehlgeschlagen. Verbindung und Service-URL prüfen.",
    "Next": "Weiter",
    "No results. Try a broader query, another category, or higher fuzziness.": "Keine Treffer. Einen allgemeineren Begriff, eine andere Kategorie oder höhere Unschärfe versuchen.",
    "Not tested yet.": "Noch nicht getestet.",
    "Number": "Hausnummer",
    "Only in the current view": "Nur im aktuellen Kartenausschnitt",
    "Only polygon or multipolygon features can be used as a search area.": "Nur Polygon- oder Multipolygonobjekte können als Suchgebiet verwendet werden.",
    "Open Settings to verify the connection.": "Einstellungen öffnen und die Verbindung prüfen.",
    "Page {page}": "Seite {page}",
    "Pick on map": "Auf Karte wählen",
    "Postcode (optional)": "Postleitzahl (optional)",
    "Previous": "Zurück",
    "QField could not create the XYZ layer.": "QField konnte die XYZ-Ebene nicht erstellen.",
    "Refresh": "Aktualisieren",
    "Refresh to load available map styles.": "Aktualisieren, um verfügbare Kartenstile zu laden.",
    "Refresh to load metadata.": "Aktualisieren, um Metadaten zu laden.",
    "Relevance": "Relevanz",
    "Replace the active GBD basemap": "Aktive GBD-Hintergrundkarte ersetzen",
    "Request failed ({status}). Check the service URL and connection.": "Anfrage fehlgeschlagen ({status}). Service-URL und Verbindung prüfen.",
    "Results must be entirely inside the selected shape": "Treffer müssen vollständig innerhalb der gewählten Fläche liegen",
    "Save and test": "Speichern und testen",
    "Search": "Suche",
    "Searching…": "Suche läuft…",
    "Select one or more polygon features first.": "Zuerst ein oder mehrere Polygonobjekte auswählen.",
    "Select polygon features in an active vector layer first.": "Zuerst Polygonobjekte in einer aktiven Vektorebene auswählen.",
    "Service connection": "Service-Verbindung",
    "Service metadata": "Service-Metadaten",
    "Settings": "Einstellungen",
    "Settings saved. Testing the connection…": "Einstellungen gespeichert. Verbindung wird getestet…",
    "Show API key": "API-Schlüssel anzeigen",
    "Show technical status": "Technischen Status anzeigen",
    "Sort order": "Sortierung",
    "Street": "Straße",
    "Street and house number are required.": "Straße und Hausnummer sind erforderlich.",
    "Style": "Stil",
    "Tap the map to search what is here.": "Auf die Karte tippen, um diesen Ort zu untersuchen.",
    "Test again": "Erneut testen",
    "The GeoServices base URL must use HTTPS.": "Die GeoServices-Basis-URL muss HTTPS verwenden.",
    "The API key is empty on a new installation and remains saved on this device after you tap Save and test.": "Bei einer Neuinstallation ist der API-Schlüssel leer und bleibt nach Speichern und testen auf diesem Gerät gespeichert.",
    "The request timed out. Try again.": "Zeitüberschreitung der Anfrage. Erneut versuchen.",
    "The selected feature geometry could not be read.": "Die Geometrie des ausgewählten Objekts konnte nicht gelesen werden.",
    "The service returned an unexpected response: {error}": "Der Service lieferte eine unerwartete Antwort: {error}",
    "Unnamed result": "Unbenannter Treffer",
    "Use selected feature(s) as search area": "Ausgewählte Objekte als Suchgebiet verwenden",
    "Unsupported search mode.": "Nicht unterstützter Suchmodus.",
    "Unsupported sort order.": "Nicht unterstützte Sortierung.",
    "What's here?": "Was ist hier?",
    "Zoom to service coverage": "Auf Service-Abdeckung zoomen",
    "e.g. Rathaus": "z. B. Rathaus",
    "name, category, place, or any mix": "Name, Kategorie, Ort oder eine Kombination",
    "{styles} styles and {formats} image formats available.": "{styles} Stile und {formats} Bildformate verfügbar.",
    "{total} results · showing {count}": "{total} Treffer · {count} angezeigt"
};

function setLanguage(locale) {
    var value = String(locale || "").replace("-", "_").toLowerCase();
    _language = value === "de" || value.indexOf("de_") === 0 ? "de" : "en";
    return _language;
}

function language() { return _language; }

function tr(source, values) {
    var translated = _language === "de" && DE[source] ? DE[source] : source;
    if (values) {
        Object.keys(values).forEach(function (key) {
            translated = translated.split("{" + key + "}").join(String(values[key]));
        });
    }
    return translated;
}

function fail(message) { throw new Error(message); }
function isObject(value) { return value !== null && typeof value === "object" && !Array.isArray(value); }
function isNumber(value) { return typeof value === "number" && isFinite(value); }
function cleanText(value) { return typeof value === "string" ? value.trim() : ""; }

function firstText() {
    for (var i = 0; i < arguments.length; i += 1) {
        var value = cleanText(arguments[i]);
        if (value) { return value; }
    }
    return "";
}

function nonNegativeInteger(value, fallback) {
    return typeof value === "number" && value >= 0 && Math.floor(value) === value ? value : fallback;
}

function normalizeBaseUrl(value) { return cleanText(String(value || "")).replace(/\/+$/, ""); }

function validateBaseUrl(value) {
    var base = normalizeBaseUrl(value);
    if (base.indexOf("https://") !== 0) { fail(tr("The GeoServices base URL must use HTTPS.")); }
    return base;
}

function encodeProviderValue(value) {
    // QGIS provider URIs need URL syntax and XYZ braces intact, while '&' and
    // '=' must not be allowed to create extra provider parameters.
    return String(value).replace(/%/g, "%25").replace(/&/g, "%26").replace(/=/g, "%3D");
}

function buildXyzUrl(baseUrl, theme, imageFormat, generation) {
    var suffix = generation > 0 ? "?v=" + Math.floor(generation) : "";
    return normalizeBaseUrl(baseUrl) + "/xyz/" + encodeURIComponent(theme) +
        "/{z}/{x}/{y}." + encodeURIComponent(imageFormat || "png") + suffix;
}

function buildXyzProviderUri(url, apiKey) {
    var uri = "type=xyz&url=" + encodeProviderValue(url) + "&zmin=0&zmax=23&crs=EPSG:3857";
    if (cleanText(apiKey)) {
        uri += "&http-header:Authorization=" + encodeURIComponent("Bearer " + cleanText(apiKey));
    }
    return uri;
}

function buildLegendUrl(baseUrl, theme, lang) {
    return normalizeBaseUrl(baseUrl) + "/legend/" + encodeURIComponent(theme) +
        ".png?lang=" + encodeURIComponent(lang || _language);
}

function displayThemeName(theme) {
    var parts = String(theme || "").split("_");
    var palettes = { std: tr("Default"), dark: tr("Dark"), light: tr("Light"), hico: tr("High contrast") };
    var details = { min: tr("Minimum"), std: tr("Default"), max: tr("Maximum") };
    var palette = palettes[parts[0]] || parts[0];
    return parts.length > 1 ? palette + " — " + (details[parts[parts.length - 1]] || parts[parts.length - 1]) : palette;
}

function buildSearchPayload(mode, options) {
    var opts = options || {};
    var cleanMode = cleanText(mode).toLowerCase();
    if (!SEARCH_MODES[cleanMode]) { fail(tr("Unsupported search mode.")); }
    var page = opts.page === undefined ? 0 : Number(opts.page);
    var limit = opts.limit === undefined ? 20 : Number(opts.limit);
    if (page < 0 || Math.floor(page) !== page || limit < 1 || Math.floor(limit) !== limit) {
        fail(tr("Invalid search page or limit."));
    }
    var sort = opts.sort || "relevance";
    if (!SORT_ORDERS[sort]) { fail(tr("Unsupported sort order.")); }
    var payload = {
        mode: cleanMode,
        page: page,
        limit: limit,
        sort: sort,
        similarity: Math.max(1, Math.min(10, Math.floor(Number(opts.similarity === undefined ? 4 : opts.similarity)))),
        lang: opts.lang || _language
    };
    var category = cleanText(opts.category);
    if (cleanMode === "address") {
        var street = cleanText(opts.street);
        var number = cleanText(opts.housenumber);
        if (!street || !number) { fail(tr("Street and house number are required.")); }
        payload.street = street;
        payload.housenumber = number;
        if (cleanText(opts.postcode)) { payload.postcode = cleanText(opts.postcode); }
        if (cleanText(opts.city)) { payload.city = cleanText(opts.city); }
    } else {
        var query = cleanText(opts.query);
        if (!query && !category) { fail(tr("Enter a query or select a category.")); }
        if (query) { payload.text = query; }
        if (category) { payload.categories = [category]; }
    }
    if (opts.area) {
        payload.area = opts.area;
        payload.within = opts.within === true;
    } else if (opts.bbox) {
        payload.bbox = opts.bbox.slice(0);
    }
    if (opts.near) { payload.near = opts.near.slice(0); }
    return payload;
}

function buildPointPayload(longitude, latitude, radius, lang) {
    var payload = { mode: "point", near: [Number(longitude), Number(latitude)], lang: lang || _language };
    if (Number(radius) > 0) { payload.radius = Math.floor(Number(radius)); }
    return payload;
}

function coordinatePairs(value, output) {
    if (!Array.isArray(value)) { return output; }
    if (value.length >= 2 && isNumber(value[0]) && isNumber(value[1])) {
        output.push([value[0], value[1]]);
        return output;
    }
    value.forEach(function (entry) { coordinatePairs(entry, output); });
    return output;
}

function geometryBounds(geometry) {
    if (!isObject(geometry)) { return null; }
    var points = coordinatePairs(geometry.coordinates, []);
    if (!points.length) { return null; }
    var west = points[0][0], south = points[0][1], east = west, north = south;
    points.slice(1).forEach(function (point) {
        west = Math.min(west, point[0]); south = Math.min(south, point[1]);
        east = Math.max(east, point[0]); north = Math.max(north, point[1]);
    });
    return [west, south, east, north];
}

function formattedAddress(props) {
    var street = [firstText(props.address_street, props.addr_street), firstText(props.address_housenumber, props.addr_housenumber)].filter(Boolean).join(" ");
    var locality = [firstText(props.address_postcode, props.addr_postcode), firstText(props.address_city, props.addr_city)].filter(Boolean).join(" ");
    return [street, locality, firstText(props.address_country, props.addr_country)].filter(Boolean).join(", ");
}

function parseFeature(feature) {
    if (!isObject(feature) || feature.type !== "Feature") { fail("A search result is not a GeoJSON Feature."); }
    if (!isObject(feature.properties)) { fail("A search feature has invalid properties."); }
    if (!isObject(feature.geometry) || !cleanText(feature.geometry.type)) { fail("A search feature has invalid GeoJSON geometry."); }
    var bounds = geometryBounds(feature.geometry);
    if (!bounds) { fail("A search feature contains no usable coordinates."); }
    var address = formattedAddress(feature.properties);
    var title = firstText(feature.properties.name, address, tr("Unnamed result"));
    var category = firstText(feature.properties.category_name, feature.properties.category);
    return {
        id: feature.id,
        title: title,
        subtitle: [address, category].filter(function (text) { return text && text !== title; }).join(" — "),
        geometry: feature.geometry,
        properties: feature.properties,
        bounds: bounds
    };
}

function parseSearchResponse(payload) {
    if (!isObject(payload)) { fail("Search response must be a JSON object."); }
    var collection = payload.results;
    if (!isObject(collection) || collection.type !== "FeatureCollection" || !Array.isArray(collection.features)) {
        fail("Search response has no GeoJSON FeatureCollection in 'results'.");
    }
    var results = collection.features.map(parseFeature);
    var page = nonNegativeInteger(payload.page, 0);
    var limit = Math.max(1, nonNegativeInteger(payload.limit, Math.max(results.length, 20)));
    var total = nonNegativeInteger(payload.total, results.length);
    return {
        results: results,
        featureCollection: collection,
        total: total,
        page: page,
        limit: limit,
        count: nonNegativeInteger(payload.count, results.length),
        hasMore: typeof payload.has_more === "boolean" ? payload.has_more : (page + 1) * limit < total,
        interpretation: payload.interpretation
    };
}

function flattenCategories(items, output, parents) {
    if (!Array.isArray(items)) { return output; }
    items.forEach(function (item) {
        if (!isObject(item)) { return; }
        var id = cleanText(item.id);
        var names = isObject(item.names) ? item.names : {};
        var label = firstText(names[_language], names.en, names.de, id);
        if (id) {
            var path = parents.concat([label]);
            output.push({ id: id, label: label, path: path.join(" › ") });
            flattenCategories(item.subcategories, output, path);
        }
    });
    return output;
}

function parseMetadata(payload) {
    if (!isObject(payload) || !Array.isArray(payload.themes)) { fail("Metadata response has no theme array."); }
    if (!Array.isArray(payload.bounds) || payload.bounds.length !== 4 || !payload.bounds.every(isNumber)) {
        fail("Metadata response has invalid bounds.");
    }
    var seen = {};
    var themes = payload.themes.map(function (item) {
        if (!isObject(item) || !cleanText(item.id)) { fail("Theme IDs must be non-empty strings."); }
        return { id: cleanText(item.id), palette: cleanText(item.palette) || cleanText(item.id).split("_")[0], detail: cleanText(item.detail) || "std" };
    }).filter(function (theme) {
        if (seen[theme.id]) { return false; }
        seen[theme.id] = true; return true;
    });
    var formats = [];
    (Array.isArray(payload.services) ? payload.services : []).forEach(function (service) {
        if (isObject(service) && service.rel === "tiles" && Array.isArray(service.formats)) {
            service.formats.forEach(function (value) {
                value = cleanText(value).toLowerCase();
                if (value && formats.indexOf(value) < 0) { formats.push(value); }
            });
        }
    });
    return {
        version: cleanText(payload.version), area: cleanText(payload.area), date: cleanText(payload.date),
        bounds: payload.bounds.slice(0), attribution: cleanText(payload.attribution), themes: themes,
        formats: formats.length ? formats : ["png"], categories: flattenCategories(payload.categories, [], [])
    };
}

function parseStatus(payload) {
    if (!isObject(payload)) { fail("Status response must be a JSON object."); }
    var raw = payload.theme_generations || payload.themes || {};
    var generations = {};
    if (Array.isArray(raw)) {
        raw.forEach(function (item) { if (isObject(item) && cleanText(item.id) && isNumber(item.generation)) { generations[item.id] = item.generation; } });
    } else if (isObject(raw)) {
        Object.keys(raw).forEach(function (key) { if (isNumber(raw[key])) { generations[key] = raw[key]; } });
    }
    return { raw: payload, generations: generations };
}

function pointWkt(longitude, latitude) { return "POINT(" + Number(longitude) + " " + Number(latitude) + ")"; }
function boundsWkt(bounds) {
    return "POLYGON((" + bounds[0] + " " + bounds[1] + "," + bounds[2] + " " + bounds[1] + "," +
        bounds[2] + " " + bounds[3] + "," + bounds[0] + " " + bounds[3] + "," + bounds[0] + " " + bounds[1] + "))";
}

function polygonMembersFromWkt(value) {
    var match = cleanText(value).match(/^(POLYGON|MULTIPOLYGON)(?:\s+(?:ZM|Z|M))?\s*(\(.*\))$/i);
    if (!match) { fail(tr("Only polygon or multipolygon features can be used as a search area.")); }
    if (match[1].toUpperCase() === "POLYGON") { return [match[2]]; }
    var inner = match[2].slice(1, -1);
    var members = [], depth = 0, start = 0;
    for (var i = 0; i < inner.length; i += 1) {
        if (inner[i] === "(") { depth += 1; }
        else if (inner[i] === ")") { depth -= 1; }
        else if (inner[i] === "," && depth === 0) {
            members.push(inner.slice(start, i).trim());
            start = i + 1;
        }
    }
    members.push(inner.slice(start).trim());
    return members.filter(Boolean);
}

function mergePolygonWkts(values) {
    if (!Array.isArray(values) || !values.length) { fail(tr("The selected feature geometry could not be read.")); }
    var members = [];
    values.forEach(function (value) { members = members.concat(polygonMembersFromWkt(value)); });
    return members.length === 1 ? cleanText(values[0]) : "MULTIPOLYGON(" + members.join(",") + ")";
}

if (typeof module !== "undefined") {
    module.exports = {
        setLanguage: setLanguage, language: language, tr: tr, normalizeBaseUrl: normalizeBaseUrl,
        validateBaseUrl: validateBaseUrl, buildXyzUrl: buildXyzUrl, buildXyzProviderUri: buildXyzProviderUri,
        buildLegendUrl: buildLegendUrl, displayThemeName: displayThemeName, buildSearchPayload: buildSearchPayload,
        buildPointPayload: buildPointPayload, geometryBounds: geometryBounds, parseSearchResponse: parseSearchResponse,
        parseMetadata: parseMetadata, parseStatus: parseStatus, pointWkt: pointWkt, boundsWkt: boundsWkt,
        mergePolygonWkts: mergePolygonWkts
    };
}
